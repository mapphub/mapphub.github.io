import{a as r}from"../chunks/BGBbb1dl.js";import{x as t}from"../chunks/BFL0zidl.js";export{t as load_css,r as start};
